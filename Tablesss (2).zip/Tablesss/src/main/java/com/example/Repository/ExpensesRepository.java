package com.example.Repository;

import com.example.Model.Expenses;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface ExpensesRepository extends MongoRepository<Expenses,String>{
}
