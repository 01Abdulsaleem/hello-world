package com.example.Service;

import com.example.Model.Company;
import com.example.Repository.CompanyRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 * Created by jeeva on 02-12-2016.
 */
@Service
public class CompanyService {

    @Autowired
    CompanyRepository companyRepository;

    public Company saveCompany(Company company){
        if(company!=null){
            company=companyRepository.save(company);
        }
        return company;
    }

}
