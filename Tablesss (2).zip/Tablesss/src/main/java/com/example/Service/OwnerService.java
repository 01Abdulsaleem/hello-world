package com.example.Service;

import com.example.Model.Owner;
import com.example.Repository.OwnerRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 * Created by briller on 05-12-2016.
 */
@Service
public class OwnerService {

    @Autowired
    OwnerRepository ownerRepository;

    public Owner saveOwner(Owner owner){
        if(owner!=null){
            owner=ownerRepository.save(owner);
        }
        return owner;
    }
}
