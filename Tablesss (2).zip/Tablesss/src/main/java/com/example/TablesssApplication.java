package com.example;

import com.example.Model.Company;
import com.example.Model.Employee;
import com.example.Model.Expenses;
import com.example.Model.Owner;
import com.example.Repository.CompanyRepository;
import com.example.Repository.EmployeeRepository;
import com.example.Repository.ExpensesRepository;
import com.example.Repository.OwnerRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.data.domain.Sort;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;

import java.util.*;

@SpringBootApplication
public class TablesssApplication {

    public static void main(String[] args) {
		SpringApplication.run(TablesssApplication.class, args);
	}

    }


