package com.example.Model;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import java.util.Date;

@Document
public class Expenses {
    @Id
    private String id;
    private String expensesType;
    private String detail;
    private String companyId;
    private String employeeId;
    private double amount;
    private Date createdAt=new Date();

    public Expenses( String expensesType, String detail,String companyId,String employeeId,  double amount) {
        this.expensesType = expensesType;
        this.detail = detail;
        this.companyId=companyId;
        this.employeeId=employeeId;
        this.amount = amount;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getExpensesType() {
        return expensesType;
    }

    public void setExpensesType(String expensesType) {
        this.expensesType = expensesType;
    }

    public String getDetail() {
        return detail;
    }

    public void setDetail(String detail) {
        this.detail = detail;
    }

    public String getCompanyId() {
        return companyId;
    }

    public void setCompanyId(String companyId) {
        this.companyId = companyId;
    }

    public String getEmployeeId() {
        return employeeId;
    }

    public void setEmployeeId(String employeeId) {
        this.employeeId = employeeId;
    }

    public double getAmount() {
        return amount;
    }

    public void setAmount(double amount) {
        this.amount = amount;
    }

    public Date getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(Date createdAt) {
        this.createdAt = createdAt;
    }

    @Override
    public String toString() {
        return "Expenses{" +
                "id='" + id + '\'' +
                ", expensesType='" + expensesType + '\'' +
                ", detail='" + detail + '\'' +
                ", companyId='" + companyId + '\'' +
                ", employeeId='" + employeeId + '\'' +
                ", amount=" + amount +
                ", createdAt=" + createdAt +
                '}';
    }
}
